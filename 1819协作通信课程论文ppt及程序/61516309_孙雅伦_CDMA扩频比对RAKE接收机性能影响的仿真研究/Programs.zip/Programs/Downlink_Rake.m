function Downlink_Rake()
% mcc -m DownLink_Rake1 -d E:\Documents\Workspace\Programs\Workspace\Debug
 
clear all;
fprintf('\nStart! Please wait...\n');
tic                 % Timing start of simulation
C = 3e8;            % Speed of light: m/s
Fc = 2.11e9;        % Carrier frequency: Hz
V = 10;             % Vehicle speed: km/h
Tc = 1/1.2288e6;    % Chip duration according to digital bandwidth
 
SF_Bit = 4;         % Order bit for spreading factor
Plt_Num = 256;      % Number of pilot symbols for channel estimation
 
SF = 2^SF_Bit;      % Spreading factor
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Generating the Walsh code matrix. The sequence number is from 0 to SF - 1  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
Index = 1;      % Index for Walsh code
Wal_Mat = 1;    % Initial state for generation of Walsh code
 
for k = 1 : SF_Bit
    Wal_Mat = [Wal_Mat Wal_Mat.*((1-2*bitget(Index,k))*ones(1,size(Wal_Mat,2)))];
end
                % Generation of Walsh code with length of 2^SF_Bit
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%  Preparing parameters for encoding and interleaver  %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
Sur_Len = 40;                           % Survior length for decoder
Code_Rate = 2;                          % Code rate for both encoder and decoder
Mem_Len = 8;                           % Memeroy length for both encoder and decoder
Fram_Len = ceil(2/(100*SF*Tc) - 0.5);       % Symbol frame length
Half_FLen = Fram_Len/2;                 % Half frame length
Calculate_Num = 30*Fram_Len;            % Number of frames for BER calculation
BitFram_Len = Fram_Len/Code_Rate;       % Bit frame length
 
Intlv_Len = BitFram_Len*Code_Rate;      % Interleaver size          
Intlv_Idx = [64 96;48 64;32 48;24 32;16 24;12 16;8 12]; % for SF_Order between 2 and 8
Intlv_Vec = reshape(1:Intlv_Len,Intlv_Idx(SF_Bit-1,1),Intlv_Idx(SF_Bit-1,2))';  % Block interleaving
Intlv_Vec = Intlv_Vec(:);               % Symbol output order of interleaver
 
SF_DB = 10*log10(SF*Code_Rate);         % General spreading factor used for SNR calculation in AWGN
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Parameters for simulating the multipath channel with modified Jakes model  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
Del_Idx = [1 2 3 4 6];                          % Path delay for Model B
Del_Gain = [0.8084 0.462 0.253 0.259 0.0447];   % Path gain for Model B
Sample_Rate = 1;                                % Oversampling_rate = 1
 
Max_Del= max(Del_Idx);              % Max time delay
Path_Num = length(Del_Idx);         % Number of paths of time invariant multipath channel
Max_Num = 3;                        % Number of fingers for RAKE combiner
 
% Generation of time invariant multipath channel
N0 = 40;                                                        % Number of scattering objects
N = 4*N0;
M = Path_Num;                                                   % Number of paths
Ank = 2*pi/(N*M)*((0:N0-1)'*ones(1,M)*M+ones(N0,1)*(0:M-1)+1/4);
Wm = 2*pi*V*Fc/C*1000/3600;                                     % Maximum Doppler frequency
phi = 2*pi*[0.8 0.28];                                          % Random Phase
 
fpname = strcat(mfilename, '.dat');
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%  Simulation Starting  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
for SNR = 0:2:20
    fprintf('\n***** SNR = %3.1f *****\n',SNR);
    
    PN_RegStateI = [zeros(1,14) 1];                 % Initial states of PNI registers
    PN_RegStateQ = [zeros(1,14) 1];                 % Initial states of PNQ registers
    PN_PolynI = [0 1 0 0 0 1 1 1 0 1 0 0 0 0 1];    % Generator function of PNI
    PN_PolynQ = [0 0 1 1 1 0 0 0 1 1 1 1 0 0 1];    % Generator function of PNQ
    
    Time_BeginCH = 0;       % Timing start of simulation with increment of frame length in Chip
    Data_Length = 0;        % Number of calculated data for BER calculation
    Err_NumRake = 0;        % Number of errors for RAKE
    Fram_Counter = 0;       % Counter of frames calculated
        
    while(Err_NumRake < 200 || Data_Length < Calculate_Num) 
        
        % Generation of source signal
        TxBits = randi([0,1],BitFram_Len - Mem_Len,1);
        TxBits_Code = cnv_enc(TxBits',Mem_Len,Code_Rate)';  % Convolutional encoding
        TxSymbols = TxBits_Code(:,Intlv_Vec);               % Block Interleaving
  
        % QPSK modulation 
        TempTxSymbols = reshape(TxSymbols,2,numel(TxSymbols)/2);   % Serial/Parallel transformation
        TxSignal = TempTxSymbols(1,:) + j*TempTxSymbols(2,:);       % Complex baseband signal
        
        % Signal repetition
        TxSig_Repeat = kron(TxSignal,ones(1,SF));   % Repeat each symbol times of spreading factor
        
        % Produce Walsh sequence with the same rate as PN code
        Walsh_Sequence = repmat(Wal_Mat,1,length(TxSignal));  % Repeat Walsh Matrix times of half symbol frame length
        
        % Produce PN code sequence
        PN_SequenceI = zeros(1,length(TxSig_Repeat));   % Initial states of PNI
        PN_SequenceQ = zeros(1,length(TxSig_Repeat));   % Initial states of PNQ
        [PN_SequenceI,PN_RegStateI] = PnGen(PN_PolynI,PN_RegStateI,length(TxSig_Repeat));
        [PN_SequenceQ,PN_RegStateQ] = PnGen(PN_PolynQ,PN_RegStateQ,length(TxSig_Repeat));
        PN_Complex = PN_SequenceI + j*PN_SequenceQ;     % Complex PN sequence
        
        % Combine PN code and Walsh code
        WalPN_Complex = PN_Complex.*Walsh_Sequence;
        
        % Spreading the signal and pilot symbols added 
        TxSig_WalPN = TxSig_Repeat.*WalPN_Complex + PN_Complex;
        
        % Passing the channel
        TxSig_WalPNM = kron(TxSig_WalPN,ones(1,Sample_Rate));   % Oversampling
        
        for kk = Time_BeginCH+1: Time_BeginCH+length(TxSig_WalPNM)
            CH_Data(:,kk-Time_BeginCH) = sqrt(1/N0)*sum(cos(Wm*cos(Ank)*(kk+1e8)*Tc/Sample_Rate+phi(1)) + j*sin(Wm*sin(Ank)*(kk+1e8)*Tc/Sample_Rate+phi(2)))';
        end
        Time_BeginCH = Time_BeginCH + length(TxSig_WalPNM); % Preparing for next frame
        
        % Multipath components according to time-delay power spectrum
        for ii = 1 : length(Del_Idx)
            if Del_Idx(1,ii) > 1
               Temp_Sig(ii,:) = [zeros(1,Del_Idx(1,ii)-1) TxSig_WalPNM(1,[1:end-Del_Idx(1,ii)+1])]; 
            else     
               Temp_Sig(ii,:) = TxSig_WalPNM(1,[1:end]);
            end
        end
        
        TxSig_WalPNCh = Del_Gain*(Temp_Sig.*CH_Data);       % Addition of multipath components with different average path gain
        TxSig_WalPNChN = TxSig_WalPNCh + [1 j]*randn(2,length(TxSig_WalPNCh))*10^((-SNR+SF_DB)/20); % Addition with complex AWGN
        
        Down_WalPNChN = TxSig_WalPNChN(1:Sample_Rate:end);  % Downsampling received signal
        
        % Channel estimation
        for ii = 1 : Max_Del
            if ii > 1
                Temp_RecSig(ii,:) = Down_WalPNChN.*[zeros(1,ii-1) conj(PN_Complex(1,1:end-ii+1))];
            else     
                Temp_RecSig(ii,:) = Down_WalPNChN.*conj(PN_Complex);
            end
        end
        
        % Get channel parameters and RAKE combining
          for i = 1:Half_FLen/Plt_Num
            Temp_EstCHR = sum( Temp_RecSig( :,(i-1)*Plt_Num*SF+1:i*Plt_Num*SF ),2)/(2*Plt_Num*SF);
            Temp_EstCH(:,i) = Temp_EstCHR; 
            Str_Idx = [1:Max_Num]';
            EstCHR = Temp_EstCHR(Str_Idx);       % Estimated channel parameters for strongest Max_Num fingers
            
            Temp_RecSigA(1,:) = Temp_RecSig(1,:);   % Received signal for the strongest finger
            for pathstr = 2 : Max_Num               % Received signals for the rest strongest fingers
               Temp_RecSigA(Str_Idx(pathstr),:) = [Temp_RecSig(Str_Idx(pathstr),[Str_Idx(pathstr):end]) zeros(1,Str_Idx(pathstr)-1)];
            end                                     % Timing alignment for RAKE combining
            for uu = 1 : Plt_Num
               RecSigRake((i-1)*Plt_Num+uu) = Wal_Mat(1,:)*Temp_RecSigA(Str_Idx,(i-1)*Plt_Num*SF+(uu-1)*SF+1:(i-1)*Plt_Num*SF+uu*SF).'*conj(EstCHR);
            end
        end
         
        % Rake Results
        EstSymbols = RecSigRake;
        Rec_Adjust = reshape([real(EstSymbols);imag(EstSymbols)],1,length(EstSymbols)*2);
        coef = sqrt(length(Rec_Adjust))/norm(Rec_Adjust);   % Power normalization
        Rec_Sigdeintlvr(Intlv_Vec,:) = coef*Rec_Adjust';    % Deinterleaving
        Rec_Sigdecode = viterbi(Rec_Sigdeintlvr,Mem_Len,Sur_Len,Code_Rate)';
        Err_NumoneRake = sum(Rec_Sigdecode ~= TxBits');
        Err_NumRake = Err_NumRake + Err_NumoneRake;
        Data_Length = Data_Length + length(TxBits);
        Fram_Counter = Fram_Counter + 1;
    end
 
    BerRake = Err_NumRake/Data_Length;
    fprintf('\n***** BER_RAKE = %10.8f *****\n',BerRake);
    
    fp = fopen(fpname,'a+');
    fprintf(fp,'%3.1f\t',SNR);
    fprintf(fp,'%10.8f\t',BerRake);
    fprintf(fp,'Time Elapsed: %f minutes\n',toc/60);
    fclose(fp);
    
    fprintf('\nNumber of Errors: %d\n',Err_NumRake);
    fprintf('\nNumber of Frames: %d\n',Fram_Counter);
    fprintf('\nFinish! Time Elapsed: %f minutes\n',toc/60);
end
