function [OutSignal] = MultiPathTV(fc, v, fs, TimeBegin, Phase, PowerDelayProfile, NonZeroPaths, TimeSignal, NoiseVar)
% This program acts to generate a Tapped-Delay-Line(TDL) channel coefficients
% via the modified Jakes's model, for which the first and second statistics
% of ndividual path waveforms agree well with the theoretical expectations.
%
%	[OutSignal] = MultiPath(fc, v, fs, t0, Duration, PowerDelayProfile, NonZeroPaths, TimeSignal)
%
%
%	Parameters:
%
%	Input:
%			fc: The carrier frequency for the simulated mobile channel.
%			v: The moving velocity of the receiver, where the transmitter is assumed to be fixed in location.
%			fs: The sampling frequency of the generated multipath channel.
%			t0: Initial time for channel simulation process.
%			Duration: The sampled channel responses number.
%			PowerDelayProfile: The power delay profile in dB for the Tapped-Delay-Line Rayleigh fading channel.
%			NonZeroPaths: Locations for nonzero paths.
%			TimeSignal	: Time waveform of signal to apply the channel to.
%			NoiseVar	: AWGN noise variance
%	Output:
%			OutSignal	: Signal via multipath and AWGN channel.


j = sqrt(-1);

tapNum = length(PowerDelayProfile);

Tc = 1/fs;
N0 = 24;
N  = 4*N0;
M  = tapNum;
Ank= 2*pi/(N*M)*((0:N0-1)'*ones(1,M)*M+ones(N0,1)*(0:M-1)+1/4);
Wm = (2*pi*v*fc/3.e+8)/3.6;

for kk = TimeBegin + 1 : TimeBegin + length(TimeSignal)
	TDLCoef(:,kk-TimeBegin)=sqrt(1/N0)*sum(cos(Wm*cos(Ank)*(kk+1e8)*Tc+Phase(1))+j*sin(Wm*sin(Ank)*(kk+1e8)*Tc+Phase(2))).';
end

%for i=1:tapNum
%  TDLCoef(i,:)=TDLCoef(i,:)./sqrt((sum(abs(TDLCoef(i,:)).^2,2)/length(TDLCoef(i,:))));
%end

TempSig = zeros(tapNum,size(TDLCoef,2));
for i = 1 : tapNum
	if NonZeroPaths(1,i) > 1
		TempSig(i,:) = [zeros(1,NonZeroPaths(1,i)-1) TimeSignal(1,[1:end-NonZeroPaths(1,i)+1])];
	else
		TempSig(i,:) = TimeSignal;
	end
end

%Mean amplitude values for different paths in decimal format:
MeanAmp = 10.^(PowerDelayProfile/10);
MeanAmp = sqrt( MeanAmp/sum(MeanAmp) );	%Nomorlized the power to 1.
OutSignal = MeanAmp*(TempSig.*TDLCoef); %pass through the multipath channel

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%   Add Gausian White Noise %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
noise = sqrt(NoiseVar)*1/sqrt(2)*(randn(1,length(TimeSignal)) + j*randn(1,length(TimeSignal)));
OutSignal = OutSignal + noise;
