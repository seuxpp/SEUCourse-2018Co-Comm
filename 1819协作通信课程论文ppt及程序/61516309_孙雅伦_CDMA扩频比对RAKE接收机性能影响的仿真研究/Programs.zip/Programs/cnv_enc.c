#include<stdio.h>
#include<math.h>
#include "mex.h"
const double Gen_2[2]={369,491},Gen_3[3]={367,435,457};

void my_cnv(double *In_Sym,double *Out_Bit,double *Gen,int Mem_Len,int Rate,int Fram_Len)
{ 
  int i,j,k,Xor_Self,Stat,Tmp;
  
  Stat=0;
  for(i=0;i<Fram_Len;i++)
   {
    if(i<Fram_Len-Mem_Len)
      Stat = ((Stat<<1)+(int)In_Sym[i])&((1<<(Mem_Len+1))-1);
    else
      Stat = (Stat<<1)&((1<<(Mem_Len+1))-1);
      
    for(j=0;j<Rate;j++)
    {
    k=Xor_Self=0;
    Tmp = Stat&(int)Gen[j];
    while((Tmp>>k)!=0)
     Xor_Self ^= (Tmp>>k++)&1;  
    *Out_Bit++ = (double)(1-(Xor_Self<<1));
    }
  }
}
void mexFunction(int nlhs,mxArray *plhs[], int nrhs,const mxArray *prhs[])
{ double *Input,*Output,*Gen,Tmp,Tmp1[6];
  double Mem_Len;
  int  k,m,n,Gm,Gn,Chg;
  Gen=Tmp1;    
  Input=mxGetPr(prhs[0]);
  m=mxGetM(prhs[0]);
  n=mxGetN(prhs[0]);
  if(m>n) {Chg=n;n=m;m=Chg;}
  Mem_Len=mxGetScalar(prhs[1]);
  
  Gm=mxGetM(prhs[2]);
  Gn=mxGetN(prhs[2]);
  
  if((Gm*Gn==1))
    {Tmp=mxGetScalar(prhs[2]);
     if(Tmp==2.0) for(k=0;k<2;k++) Tmp1[k]=Gen_2[k];
     if(Tmp==3.0) for(k=0;k<3;k++) Tmp1[k]=Gen_3[k];
     Gn=(int)Tmp;
    }
  else Gen=mxGetPr(prhs[2]);     
  
  if(Gm>Gn) Gn=Gm; /*Gn is Rate*/
  if(nrhs<3) 
    mexErrMsgTxt("The number of input variable Must be three!"
        "         You shoud input in the following formation:"
        "      convol(In_Symbol,Memory_Length,Gen_Polynomial)"
        "      Good Luck! More detail,see convol.c");
     
  plhs[0]= mxCreateDoubleMatrix(Gn*(n+(int)Mem_Len),m,mxREAL); 
  Output=mxGetPr(plhs[0]);
for(k=0;k<m;k++)
  my_cnv(Input+k*n,Output+k*Gn*(n+(int)Mem_Len),Gen,(int)Mem_Len,Gn,n+(int)Mem_Len); 
}