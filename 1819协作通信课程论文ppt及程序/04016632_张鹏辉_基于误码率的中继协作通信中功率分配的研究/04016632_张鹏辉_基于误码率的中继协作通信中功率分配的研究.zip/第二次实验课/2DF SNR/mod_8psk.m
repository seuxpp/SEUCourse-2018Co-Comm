function mod_data=mod_8psk(bin_data)

if rem(length(bin_data),3)~=0
   error('the length of the data is wrong');
else
    matr_bin=reshape(bin_data,3,length(bin_data)/3)';
    matr_dec=bi2de(matr_bin,2,'left-msb');
    aa=tan(3*pi/8)/sqrt(6);
    bb=tan(pi/8)/sqrt(6);
    pskTable=[aa+j*bb   bb+j*aa  -bb+j*aa -aa+j*bb  ...
               -aa-j*bb  -bb-j*aa bb-j*aa  aa-j*bb ];
     mod_data=pskTable(matr_dec+1);     
end
