function bin_data=demod_8psk(mod_data)
bin_data=[];
for i=1:length(mod_data)
    rr=real(mod_data(i));
    ii=imag(mod_data(i));
    if(rr>0&ii>0&(abs(rr)>abs(ii)))
        bin_data=[bin_data 0 0 0];
    end
    if(rr>0&ii>0&(abs(rr)<abs(ii)))
        bin_data=[bin_data 0 0 1];
    end
   if(rr<0&ii>0&(abs(rr)<abs(ii)))
             bin_data=[bin_data 0 1 0];
   end
   if(rr<0&ii>0&(abs(rr)>abs(ii)))
             bin_data=[bin_data 0 1 1];
   end
   if(rr<0&ii<0&(abs(rr)>abs(ii)))
             bin_data=[bin_data 1 0 0];
   end
   if(rr<0&ii<0&(abs(rr)<abs(ii)))
             bin_data=[bin_data 1 0 1]; 
   end
   if(rr>0&ii<0&(abs(rr)<abs(ii)))
             bin_data=[bin_data 1 1 0];
   end
   if(rr>0&ii<0&(abs(rr)>abs(ii)))
             bin_data=[bin_data 1 1 1];
   end
end