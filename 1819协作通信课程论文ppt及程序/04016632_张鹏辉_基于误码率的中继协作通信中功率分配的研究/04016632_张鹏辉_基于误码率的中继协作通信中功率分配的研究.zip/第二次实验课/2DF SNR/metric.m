function distance=metric(x,y)
if x==y
    distance=0;
else 
    distance=1;
end
% switch (y)
% case 0
%     if x==0
%         distance=0.0458;
%     end
%     if x==1
%         distance=2;
%     end
%     if x==2;
%         distance==1.0458;
%     end
% case 1
%     if x==0
%         distance==2;
%     end
%     if x==1
%         distance=0.0458;
%     end
%     if x==2
%         distance=1.0458;
%     end
% otherwise,
%     break;
% end