function [rx]=rx_reset(rx);
%��rx��λ

rx.received_signal=[];
rx.signal2analyse=[];