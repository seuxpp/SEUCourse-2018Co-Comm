clc;
clear;
syms v;
lambda=0.25;
segma=2;
T=-10:1:20;
T_db = 10.^(T/10);
p = sqrt(T_db).*(pi/2-atan(1./sqrt(T_db)));
y=exp(-pi.*lambda.*v.*(1+(1./segma).*p));
prob=pi*lambda.*int(y,v,0.000001,500);
plot(-10:1:20,prob,'g');
xlabel('SINR Threshold (dB)');
ylabel('Probability of coverage');
hold on;
% prob=1./(1+p./segma);
% plot(-10:1:20,prob,'r')
N=24;
R=1;
mu=1;
alpha=4; 
sigma2=0;
N_simu = 100000;
i=0;
x_BS=[-4*R,0,4*R,-2*R,2*R,-4*R,4*R,-2*R,2*R,-4*R,0,4*R];
y_BS=[4*R,4*R,4*R,2*R,2*R,0,0,-2*R,-2*R,-4*R,-4*R,-4*R];
for SINR = -10:1:20
 i = i + 1;
 SINR_db = 10^(SINR/10);
 no_coverage = 0;
 for j = 1:N_simu
 x_u = 2*rand(1)-1;
 y_u = 2*rand(1)-1;
 h=exprnd(mu,N/2+1,1);
 inter = 0;
 for k = 1:N/2
 inter = inter + h(k)*sqrt((x_BS(k)-x_u)^2+(y_BS(k)-y_u)^2)^(-alpha);
 end
 signal_power = h(N/2+1)*sqrt(x_u^2+y_u^2)^(-alpha);
 SINR_current = signal_power / (inter + sigma2);
 if SINR_current > SINR_db
 no_coverage = no_coverage + 1;
 end
 end
 prob(i) = no_coverage / N_simu;
end
plot(-10:1:20,prob,'--k')
grid on;
legend('n=1','n=2');
