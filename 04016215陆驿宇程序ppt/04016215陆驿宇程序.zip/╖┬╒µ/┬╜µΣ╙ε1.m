clc;
clear;
SINR_db = -10:1:20;
SINR = 10.^(SINR_db/10);
prob = 1./(1+sqrt(SINR).*(pi/2-atan(1./sqrt(SINR))));
plot(-10:1:20, prob,'k^');
xlabel('SINR Threshold (dB)');
ylabel('Pc');
hold on;
SNR_db = 10;
SNR = 10^(SNR_db/10);
lambda = 0.25;
i=0;
for T = -10:1:20
 i = i+1;
 T_db = 10^(T/10);
 ka = 1 + sqrt(T_db)*(pi/2-atan(1/sqrt(T_db)));
 prob(i) = pi^1.5 * lambda / sqrt(T_db/SNR) * exp((lambda*pi*ka)^2/...
 (4*T_db/SNR))*qfunc(lambda*pi*ka/sqrt(2*T_db/SNR));
end
plot(-10:1:20,prob,'g')
N=8;
R=1;
mu=1;
SNR_db=10;
SNR=10^(SNR_db/10);
alpha=4;
x_BS=[-2*R,2*R,-2*R,0,0,2*R,2*R,2*R,];
y_BS=[-2*R,0,2*R,-2*R,2*R,-2*R,0,2*R,];
sigma2=1/(SNR*mu);
N_simu = 30000;
i=0;
for SINR = -10:1:20
 i = i + 1;
 SINR_db = 10^(SINR/10);
 no_coverage = 0;
 for j = 1:N_simu
 x_u = 2*rand(1)-1;
 y_u = 2*rand(1)-1;
 h=exprnd(mu,N+1,1);
 inter = 0;
 for k = 1:N
 inter = inter + h(k)*sqrt((x_BS(k)-x_u)^2+(y_BS(k)-y_u)^2)^(-alpha);
 end
 signal_power = h(N+1)*sqrt(x_u^2+y_u^2)^(-alpha);
 SINR_current = signal_power / (inter + sigma2);
 if SINR_current > SINR_db
 no_coverage = no_coverage + 1;
 end
 end
 prob(i) = no_coverage / N_simu;
end
 plot(-10:1:20,prob,'b')
N=24;
R=1;
mu=1;
SNR_db=10;
SNR=10^(SNR_db/10);
alpha=4;
sigma2=1/(SNR*mu);
N_simu = 100000;
i=0;
x_BS=[-4*R,-2*R,0,2*R,4*R,-4*R,-2*R,0,2*R,4*R,-4*R,-2*R,2*R,4*R,-4*R,-2*R,0,2*R,4*R,-4*R,-2*R,0,2*R,4*R];
y_BS=[4*R,4*R,4*R,4*R,4*R,2*R,2*R,2*R,2*R,2*R,0,0,0,0,-2*R,-2*R,-2*R,-2*R,-2*R,-4*R,-4*R,-4*R,-4*R,-4*R];
for SINR = -10:1:20
 i = i + 1;
 SINR_db = 10^(SINR/10);
 no_coverage = 0;
 for j = 1:N_simu
 x_u = 2*rand(1)-1;
 y_u = 2*rand(1)-1;
 h=exprnd(mu,N+1,1);
 inter = 0;
 for k = 1:N
 inter = inter + h(k)*sqrt((x_BS(k)-x_u)^2+(y_BS(k)-y_u)^2)^(-alpha);
 end
 signal_power = h(N+1)*sqrt(x_u^2+y_u^2)^(-alpha);
 SINR_current = signal_power / (inter + sigma2);
 if SINR_current > SINR_db
 no_coverage = no_coverage + 1;
 end
 end
 prob(i) = no_coverage / N_simu;
end
 plot(-10:1:20,prob,'--c')
N=24;
R=1;
mu=1;
%SNR_db=10;
%SNR=10^(SNR_db/10);
alpha=4;
%sigma2=1/(SNR*mu);
N_simu = 30000;
i=0;
x_BS=[-4*R,-2*R,0,2*R,4*R,-4*R,-2*R,0,2*R,4*R,-4*R,-2*R,2*R,4*R,-4*R,-2*R,0,2*R,4*R,-
4*R,-2*R,0,2*R,4*R];
y_BS=[4*R,4*R,4*R,4*R,4*R,2*R,2*R,2*R,2*R,2*R,0,0,0,0,-2*R,-2*R,-2*R,-2*R,-2*R,-
4*R,-4*R,-4*R,-4*R,-4*R];
for SINR = -10:1:20
 i = i + 1;
 SINR_db = 10^(SINR/10);
 no_coverage = 0;
 for j = 1:N_simu
 x_u = 2*rand(1)-1;
 y_u = 2*rand(1)-1;
 h=exprnd(mu,N+1,1);
 inter = 0;
 for k = 1:N
 inter = inter + h(k)*sqrt((x_BS(k)-x_u)^2+(y_BS(k)-y_u)^2)^(-alpha);
 end
 signal_power = h(N+1)*sqrt(x_u^2+y_u^2)^(-alpha);
 SINR_current = signal_power / (inter);
 if SINR_current > SINR_db
 no_coverage = no_coverage + 1;
 end
 end
 prob(i) = no_coverage / N_simu;
end
 plot(-10:1:20,prob,'or')


grid on;
legend('n=1','n=2','n=3','n=4','Grid
N=24,No Noise');